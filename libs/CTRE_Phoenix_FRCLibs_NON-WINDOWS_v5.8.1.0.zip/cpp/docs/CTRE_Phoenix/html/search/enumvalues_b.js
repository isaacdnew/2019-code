var searchData=
[
  ['scl',['SCL',['../classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceaa360ea8d8c39de4b61a2971332732670',1,'ctre::phoenix::CANifier']]],
  ['sda',['SDA',['../classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceab3def09f82ae0b229e966df5c2d11a3f',1,'ctre::phoenix::CANifier']]],
  ['spi_5fclk_5fpwm0p',['SPI_CLK_PWM0P',['../classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea64af2cd0e72739d95a8be160b2001497',1,'ctre::phoenix::CANifier']]],
  ['spi_5fcs',['SPI_CS',['../classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceab57b38e73926ce356f0260f6109cf7aa',1,'ctre::phoenix::CANifier']]],
  ['spi_5fmiso_5fpwm2p',['SPI_MISO_PWM2P',['../classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea752005f79c9ff271abbd2029f5fb928f',1,'ctre::phoenix::CANifier']]],
  ['spi_5fmosi_5fpwm1p',['SPI_MOSI_PWM1P',['../classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea0bb2891848b1761293cf890bfc48193b',1,'ctre::phoenix::CANifier']]]
];
