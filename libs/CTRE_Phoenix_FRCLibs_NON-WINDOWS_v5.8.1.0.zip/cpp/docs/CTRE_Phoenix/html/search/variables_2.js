var searchData=
[
  ['bcalisbooting',['bCalIsBooting',['../structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_1_1_general_status.html#a1a3316ca723139a801df807c8097a564',1,'ctre::phoenix::sensors::PigeonIMU::GeneralStatus']]],
  ['bisfusing',['bIsFusing',['../structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_1_1_fusion_status.html#a7e64a95eb66cedf7a2860b7940ccb79f',1,'ctre::phoenix::sensors::PigeonIMU::FusionStatus']]],
  ['bisvalid',['bIsValid',['../structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_1_1_fusion_status.html#a64b03df4873ea57d57a32e6f5afc878d',1,'ctre::phoenix::sensors::PigeonIMU::FusionStatus']]]
];
