var searchData=
[
  ['openloopramp',['openloopRamp',['../structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller_configuration.html#a336eafe47abc376bd4519a200e0e7769',1,'ctre::phoenix::motorcontrol::can::BaseMotorControllerConfiguration']]]
];
