var searchData=
[
  ['tempc',['tempC',['../structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_1_1_general_status.html#aaf309fd4855040ac6f9df8ba2882b9a2',1,'ctre::phoenix::sensors::PigeonIMU::GeneralStatus']]],
  ['tempcompensationcount',['tempCompensationCount',['../structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_1_1_general_status.html#a35b60c38962b9215ed036aadacb2c1bf',1,'ctre::phoenix::sensors::PigeonIMU::GeneralStatus']]]
];
