var searchData=
[
  ['movingaverage_2eh',['MovingAverage.h',['../_moving_average_8h.html',1,'']]]
];
