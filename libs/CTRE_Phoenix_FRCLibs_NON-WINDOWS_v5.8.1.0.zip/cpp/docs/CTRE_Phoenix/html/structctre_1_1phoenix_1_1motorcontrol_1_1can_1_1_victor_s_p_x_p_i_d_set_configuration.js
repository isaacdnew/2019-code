var structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_p_i_d_set_configuration =
[
    [ "VictorSPXPIDSetConfiguration", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_p_i_d_set_configuration.html#a5c80a78544e10a589a0846860096a8f6", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_p_i_d_set_configuration.html#a25094acb9e19a7cce67806feba6119fe", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_p_i_d_set_configuration.html#ab61efb3fbdfa5e285f14b6537b137cbf", null ],
    [ "selectedFeedbackSensor", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_p_i_d_set_configuration.html#ab6db0d13d2e4fb54e36108be577409a9", null ]
];