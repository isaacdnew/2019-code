var structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_p_i_d_set_configuration =
[
    [ "BasePIDSetConfiguration", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_p_i_d_set_configuration.html#a0e390e019f47886bfafc7fe9ca5a0a37", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_p_i_d_set_configuration.html#a75938d42dc85866ac208c95d31abc511", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_p_i_d_set_configuration.html#af65cf17c9d1d8542b196dc087b139bcb", null ],
    [ "selectedFeedbackCoefficient", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_p_i_d_set_configuration.html#a6b9ffae7bb8e31d31e0cc960cde6eb6b", null ]
];