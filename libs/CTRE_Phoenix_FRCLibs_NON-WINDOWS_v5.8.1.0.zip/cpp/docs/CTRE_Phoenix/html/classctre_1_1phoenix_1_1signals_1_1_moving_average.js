var classctre_1_1phoenix_1_1signals_1_1_moving_average =
[
    [ "MovingAverage", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#a3a99b65fbf9f80ca3473f8f2b26e6858", null ],
    [ "Clear", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#aee1a9e0fe290e66123ff065c808ea98e", null ],
    [ "GetCount", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#a99cfa0f4e15cd4da21f1ed7c7b83a85b", null ],
    [ "GetSum", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#ad3dda5371d7fea075b98a6ab80199e45", null ],
    [ "Pop", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#a0e3afedea20bfe5e9fb43adb2f8be194", null ],
    [ "Process", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#a1a197401e03a623c0a875074b5507005", null ],
    [ "Push", "classctre_1_1phoenix_1_1signals_1_1_moving_average.html#a8201527fab81d79775a4c5bb5dacd755", null ]
];