var namespacectre_1_1phoenix_1_1sensors =
[
    [ "PigeonIMU", "classctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u.html", "classctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u" ],
    [ "PigeonIMUConfiguration", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_configuration.html", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_configuration" ],
    [ "PigeonIMUConfigUtils", "structctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u_config_utils.html", null ]
];