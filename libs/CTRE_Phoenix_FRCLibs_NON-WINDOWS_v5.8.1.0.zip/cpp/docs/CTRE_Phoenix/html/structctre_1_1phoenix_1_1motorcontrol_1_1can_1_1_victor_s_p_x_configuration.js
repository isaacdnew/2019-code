var structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration =
[
    [ "VictorSPXConfiguration", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#ac862e46ac4947d0d844cd0cb5a0393fb", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#ad7ed07d1d30c482607d8fa386ba67f70", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a39246a7dd99ab3ec1b77343e1365c010", null ],
    [ "auxilaryPID", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a18b2ec19e5f208c4642149dcf79b465c", null ],
    [ "diff0Term", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a436ea5bec710a0f6a0a7e07df3e56fb9", null ],
    [ "diff1Term", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a4f85b45dd31f58dc987e326c32f3e1de", null ],
    [ "forwardLimitSwitchDeviceID", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a796106455c40297bc1216b65e804e68a", null ],
    [ "forwardLimitSwitchNormal", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a3bb4d6f733ed156acb569bb8da4ae698", null ],
    [ "forwardLimitSwitchSource", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#adc611b3898a6b0236beb6ac4817071be", null ],
    [ "primaryPID", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a3c930fce1cb9bfa8d2508c3a3284ae81", null ],
    [ "reverseLimitSwitchDeviceID", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a1e4ddc8154dbeba099e98ef4a8630090", null ],
    [ "reverseLimitSwitchNormal", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a5bde03eeb01b7a98d061a438dae9a085", null ],
    [ "reverseLimitSwitchSource", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a88901b52d5fa81dbc5b6c6210476e94b", null ],
    [ "sum0Term", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#a9b59b4ec31e0d0399cd28922f9914eb9", null ],
    [ "sum1Term", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_victor_s_p_x_configuration.html#aa0a086bdb788316611f8aa3f4b7600d9", null ]
];