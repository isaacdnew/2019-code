var NAVTREE =
[
  [ "CTRE_Phoenix", "index.html", [
    [ "Deprecated List", "deprecated.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_base_motor_controller_8cpp.html",
"classctre_1_1phoenix_1_1motorcontrol_1_1_i_motor_controller.html#aa9bef2d7f13f3b7a9e88bcb8b286a598",
"classctre_1_1phoenix_1_1sensors_1_1_pigeon_i_m_u.html#a2aeed4b66526cb5af565f964239b4061",
"structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_base_motor_controller_configuration.html#a26fe6fa002da45a0ef9caa333e2f6a77"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';