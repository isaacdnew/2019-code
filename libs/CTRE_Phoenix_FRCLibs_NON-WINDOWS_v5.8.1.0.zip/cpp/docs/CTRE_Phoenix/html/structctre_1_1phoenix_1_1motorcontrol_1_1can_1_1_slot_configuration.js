var structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration =
[
    [ "SlotConfiguration", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a691c9e2d9c915ae701405411a682d447", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a7de4753e303ddc170511f81795f60b50", null ],
    [ "toString", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a3f12126529faa11a67dd4f885e537a35", null ],
    [ "allowableClosedloopError", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#adbb4f3627dece9d3dc807fd5375c215b", null ],
    [ "closedLoopPeakOutput", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#aebfff3ab32772b55473f04620211e364", null ],
    [ "closedLoopPeriod", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a4d9f2754408e627128a5d8f54287a114", null ],
    [ "integralZone", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a04c3ad86537c7e5edbcaeb42c8af1a70", null ],
    [ "kD", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a44ab0963ac958f7a70198c72436416b3", null ],
    [ "kF", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#adb031fa54a1b1608b107e5c53f669db1", null ],
    [ "kI", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#ab98fce70cc6543d083bf9d2694f17643", null ],
    [ "kP", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#ac2cc8f9a248d8fb22d926e60dcd6999c", null ],
    [ "maxIntegralAccumulator", "structctre_1_1phoenix_1_1motorcontrol_1_1can_1_1_slot_configuration.html#a033d5ebec06e5d49d58f5e80db89c2a7", null ]
];